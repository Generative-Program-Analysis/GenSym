#ifndef MOCKUPS_H
#define MOCKUPS_H

void assume(int);
void assert(int);
void* alloc(int, int);
void dealloc(void*);
int sym_int(char*);

#endif
